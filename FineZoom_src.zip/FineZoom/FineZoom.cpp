#include "f4se/PluginAPI.h"
#include "f4se/GameAPI.h"
#include <shlobj.h>
#include <fstream>
#include "common/IDebugLog.h"

#include "f4se_common/f4se_version.h"

#include "f4se/PapyrusVM.h"
#include "f4se/PapyrusNativeFunctions.h"

#include "Config.h"

#include "Logic.h"

IDebugLog gLog;

BOOL WINAPI DllMain(HINSTANCE hInst, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        gLog.OpenRelative(CSIDL_MYDOCUMENTS, "\\My Games\\Fallout4\\F4SE\\FineZoom.log");
        _MESSAGE("Dll attach begin");
        Logic::setHInstance(hInst);

        _MESSAGE("Dll attach end");
    }

    if (reason == DLL_PROCESS_DETACH) {
        _MESSAGE("Dll deattach begin");

        Logic::cleanUp();

        _MESSAGE("Dll deattach end");
        return 1;
    }

    return 1;
}

extern "C"
{

// F4SE 0.7.x no longer calls F4SEPlugin_Query. Instead it reads this block
// and loads the plugin only if the running game version is listed in it.
__declspec(dllexport) F4SEPluginVersionData F4SEPlugin_Version = {
    F4SEPluginVersionData::kVersion,

    PLUGIN_VERSION,
    PLUGIN_NAME_LONG,
    "",                                 // author (left blank)

    0,                                  // address independence: none (addresses come from FineZoomMem_v<version>.ini)
    F4SEPluginVersionData::kStructureIndependence_1_10_980Layout | F4SEPluginVersionData::kStructureIndependence_1_11_137Layout,
    { 0x010B0DD0, 0 },                  // compatible game version: 1.11.221 (zero-terminated list)

    0,                                  // works with any F4SE version
};

__declspec(dllexport) bool F4SEPlugin_Load(const F4SEInterface *f4se) {
    _MESSAGE("FineZoom v%s", PLUGIN_VERSION_STRING);
    _MESSAGE("FineZoom load");

    // Everything the old F4SEPlugin_Query did (saving the plugin handle and the
    // Papyrus / Messaging interfaces) has to happen here now, because F4SE 0.7.x
    // never calls Query. Without this, Load crashes on empty pointers.
    if (!Logic::query(f4se)) {
        return false;
    }

    return Logic::load(f4se);
}
}
