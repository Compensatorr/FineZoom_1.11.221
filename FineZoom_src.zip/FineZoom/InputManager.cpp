#include "InputManager.h"

#include "common/IDebugLog.h"
#include "MemoryManager.h"
#include "Logic.h"
#include "SettingsConfig.h"

// Mouse-wheel input only. The gamepad (GLFW) code of the original was removed:
// zoom is driven by scroll-wheel events, which can also be produced by a
// macro tool that maps controller buttons to the mouse wheel.

HHOOK InputManager::mouseHook{};

static LRESULT CALLBACK MouseCallback(int code, WPARAM wparam, LPARAM lparam) {

    if (code < 0) {
        return CallNextHookEx(InputManager::getMouseHook(), code, wparam, lparam);
    }

    auto *info = reinterpret_cast<MOUSEHOOKSTRUCTEX *>(lparam);

    if (wparam == WM_MOUSEWHEEL) {
        short delta = HIWORD(info->mouseData);
        if (delta > 0) {
            Logic::changeZoom(SettingsConfig::settings.reverseScrollDirection ? -1.0f : 1.0f);
            _MESSAGE("Scroll in");
        } else if (delta < 0) {
            Logic::changeZoom(SettingsConfig::settings.reverseScrollDirection ? 1.0f : -1.0f);
            _MESSAGE("Scroll out");
        }
    }

    return CallNextHookEx(InputManager::getMouseHook(), code, wparam, lparam);
}

void InputManager::setupInput(HINSTANCE hInstance, DWORD threadID) {
    mouseHook = SetWindowsHookEx(WH_MOUSE, &MouseCallback, hInstance, threadID);
    _MESSAGE("Mouse hook: %s", mouseHook ? "Success" : "Error");
}

void InputManager::update() {
    // Nothing to poll: mouse-wheel events arrive through the hook above.
}

const HHOOK InputManager::getMouseHook() {
    return mouseHook;
}

void InputManager::cleanUp() {
    if (mouseHook) {
        UnhookWindowsHookEx(mouseHook);
        mouseHook = nullptr;
    }
}
