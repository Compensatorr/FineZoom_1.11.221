#pragma once
#include "f4se_common/f4se_version.h"

#define MAKE_VERSION(major, minor, patch) ((major & 0xFF) << 16) | ((minor & 0xFF) << 8) | (patch & 0xFF)

//-----------------------
// Plugin Information
//-----------------------
#define PLUGIN_VERSION               MAKE_VERSION(0,3,7)
#define PLUGIN_VERSION_STRING       "0.3.7"
#define PLUGIN_NAME_SHORT           "FineZoom"
#define PLUGIN_NAME_LONG            "FineZoom"
// (The old runtime-version macros were removed: F4SE 0.7.x does the version check itself,
//  using the list in F4SEPlugin_Version in FineZoom.cpp.)